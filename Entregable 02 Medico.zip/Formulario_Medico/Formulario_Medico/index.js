const express = require('express');
const app = express();

app.use(express.json());

const doctores=[
  {id: 1, nombre:'David',apellido:'Suarez',numeroced: 1234567890, especialidad:'Medicina General',consultorio: 202,correocont: 'david.suarez@prueba.com'},
  {id: 2, nombre:'Alejandro',apellido:'Diaz',numeroced: 98765432, especialidad:'Cardiología',consultorio: 402,correocont: 'alejandro.diaz@prueba.com'},
  
];


app.get('/',(req, res)=>{
  res.send('Node JS app');
});

app.get('/api/doctores',(req,res)=>{
  res.send(doctores);
});

app.get('/api/doctores/:id',(req, res)=>{
   const doctor = doctores.find(c=>c.id===parseInt(req.params.id));
   if(!doctor) return res.status(404).send('Doctor no encontrado');
   else res.send(doctor);
});

app.post('/api/doctores',(req, res)=>{
  const doctores ={
    id: doctores.length +1,
    name : req.body.name,
    age: parseInt(req.body.age),
    enrroll : (req.body.enroll==='true')
  };
  doctores.push(doctores);
  res.send(doctores);
})

app.delete('/api/doctores/:id',(req, res)=>{
  const doctor = doctores.find(c => c.id === parseInt(req.params.id));
  if (!doctor) return res.status(404).send('Doctor no encontrado');

  const index = doctores.indexOf(doctores);
  doctores.splice(index, 1);
  res.send(doctores);
});

const port = process.env.port || 80;
app.listen(port, ()=> console.log(`Escuchando en el puerto ${port}...`));
