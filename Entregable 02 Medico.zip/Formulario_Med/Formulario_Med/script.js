document.getElementById("doctorForm").addEventListener("submit", function(event) {
    event.preventDefault();
  
    const nombre = document.getElementById("nombre").value;
    const apellido = document.getElementById("apellido").value;
    const numeroced = document.getElementById("numeroced").value;
    const especialidad = document.getElementById("especialidad").value;
    const consultorio = document.getElementById("consultorio").value;
    const correocont = document.getElementById("correocont").value;
  
    const doctorData = {
      nombre: nombre,
      apellido: apellido,
      numeroced: numeroced,
      especialidad: especialidad,
      consultorio: consultorio,
      correocont: correocont,
    };
  
    fetch('/api/doctores', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(doctorData)
    })
    .then(response => response.json())
    .then(data => {
      console.log('Doctor guardado:', data);
      alert('Doctor guardado exitosamente');
      document.getElementById("doctorForm").reset();
    })
    .catch(error => {
      console.error('Error al guardar el doctor:', error);
      alert('Error al guardar el doctor');
    });
  });