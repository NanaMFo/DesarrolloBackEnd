// El campo nombre no puede estar en blanco.
function validartxtNombre() {
    var enviar = false;
    var objeto = document.getElementById("txtNombre");
    var spanerror = document.getElementById("txtNombreError");
    if ((objeto.value).length > 0) {
        // ocultar el span
        spanerror.className = "error0";
        // Cumple la condición, se cambia el estado de enviar a true
        return enviar = true;
    } else {
        // No cumple, se lanza error y se muestra span con mensaje de error
        spanerror.innerHTML="+Error, el campo nombre no puede estar en blanco.";
        // activar visibilidad del span error
        spanerror.className = "error1";
        // Se cambia el estado de enviar a false por no cumplir requisitos
        return enviar = false;
    }
}

// Los apellidos no pueden estar en blanco.
function validartxtApellidos() {
    var enviar = false;
    var objeto = document.getElementById("txtApellidos");
    var spanerror = document.getElementById("txtApellidosError");
    if ((objeto.value).length > 0) {
      // Cumple la condición, comprobar que tiene espacio. Por ello habra varios apellidos
        if (/\s/.test(objeto.value)) {
            // ocultar el span
            spanerror.className = "error0";
            // Cumple la condición, se cambia el estado de enviar a true
            return enviar = true;
        } else {
            // No cumple, se lanza error y se muestra span con mensaje de error
            spanerror.innerHTML="Error, campo apellido no puede estar en blanco.";
            // activar visibilidad del span error
            spanerror.className = "error1";
            // Se cambia el estado de enviar a false por no cumplir requisitos
            return enviar = false;
        }
        
    } else {
        // No cumple, se lanza error y se muestra span con mensaje de error
        spanerror.innerHTML="Error, campo apellido no puede estar en blanco.";
        // activar visibilidad del span error
        spanerror.className = "error1";
        // Se cambia el estado de enviar a false por no cumplir requisitos
        return enviar = false;
    }
}

// La edad debe estar comprendida entre 0 y 120 y ser de tipo número.
function validarnumEdad() {
    var enviar = false;
    var edadFormul = document.getElementById("numEdad").value;
    var spanerror = document.getElementById("numEdadError");
    // si es un numero entra al otro if que comprueba el rango del numero
    if (!isNaN(edadFormul)){
        // si no cumple la condicion error
        if (edadFormul >= 0 && edadFormul <= 120) {
            // ocultar el span
            spanerror.className = "error0";
            // Cumple la condición, se cambia el estado de enviar a true
            return enviar = true;
        } else {
            // No cumple, se lanza error y se muestra span con mensaje de error
            spanerror.innerHTML="Error, edad debe estar entre 0 y 120";
            // activar visibilidad del span error
            spanerror.className = "error1";
            // Se cambia el estado de enviar a false por no cumplir requisitos
            return enviar = false;
        }
    }
     else {
        // No cumple, se lanza error y se muestra span con mensaje de error
        spanerror.innerHTML="Error, la edad debe ser un numero";
        // activar visibilidad del span error
        spanerror.className = "error1";
        // Se cambia el estado de enviar a false por no cumplir requisitos
        return enviar = false;
    }
}

// Se deberá rellenar al menos un teléfono de contacto.
function numFijooMovil() {
    var enviar = false;
    var fijo = document.getElementById("numTelefFijo");
    var spanerror = document.getElementById("numTelefFijoError");
    // comprobar que no esten vacios
    if (!fijo.value == "" || !movil.value == ""  ) {
        if ((fijo.value).length == 9 || (movil.value).length == 9  ) {
            // ocultar el span
            spanerror.className = "error0";
            // Cumple la condición, se cambia el estado de enviar a true
            return enviar = true;
        } else {
            // No cumple, se lanza error y se muestra span con mensaje de error
            spanerror.innerHTML="Error, el teléfono debe tener 10 digitos";
            // activar visibilidad del span error
            spanerror.className = "error1";
            // Se cambia el estado de enviar a false por no cumplir requisitos
            return enviar = false;
        }
    } else {
        // No cumple, se lanza error y se muestra span con mensaje de error
        spanerror.innerHTML="Error, inserte teléfono de contacto.";
        // activar visibilidad del span error
        spanerror.className = "error1";
        // Se cambia el estado de enviar a false por no cumplir requisitos
        return enviar = false;
    }
}
// boton especialidad automática.
function autoespecialidadSelec() {
    var especialidad = document.getElementById("especialidadSelec");
    var cp = document.getElementById("especialidadSelec");
    var spanerror = document.getElementById("especialidadSelec");
    if (!cp.value == "" && (cp.value).length == 5) {
        // ocultar el span
        spanerror.className = "error0";
        //obtener los 2 primeros numeros
        if ((cp.value).substr(0, 2) == "29"){
            espec.selectedIndex=1;
        } else if ((cp.value).substr(0, 2) == "23"){
            espec.selectedIndex=7;
        } else if ((cp.value).substr(0, 2) == "11"){
            espec.selectedIndex=2;
        } else if ((cp.value).substr(0, 2) == "41"){
            espec.selectedIndex=8;
        } else if ((cp.value).substr(0, 2) == "04"){
            espec.selectedIndex=3;
        } else if ((cp.value).substr(0, 2) == "18"){
            espec.selectedIndex=5;
        } else if ((cp.value).substr(0, 2) == "14"){
            espec.selectedIndex=4;
        } else if ((cp.value).substr(0, 2) == "21"){
            espec.selectedIndex=6;
        } else {
            espec.selectedIndex=0;
        }
        
    } else {
        // No hay ninguna opcion seleccionada, se lanza error y se muestra span con mensaje de error
        spanerror.innerHTML="Error, seleccione especialidad";
        // activar visibilidad del span error
        spanerror.className = "error1";
    }
}

// funcion a ejecutar cuando se pulse el boton enviar
function enviarFormulario() {
    var contador=0;
    if ( validartxtNombre() ) {
        contador++;
    }
    if ( validartxtApellidos() ) {
        contador++;
    }
    if ( validartxtNumCedula() ) {
        contador++;
    }
    if ( validarnumEdad() ) {
        contador++;
    }
    if ( numTelefFijo() ) {
        contador++;
    }
    
    if ( contador == 10 ) {
        // si ha pasado la valición mostrar alert y enviar formulario
        alert("Formulario enviado correctamente, gracias.");
        document.formulario1.submit();
    }
}