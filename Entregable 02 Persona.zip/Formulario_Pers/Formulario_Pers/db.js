const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: '',
  password: 't',
  database: ''
});

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar con la base de datos:', err);
    return;
  }
  console.log('Conexión exitosa a la base de datos');
});

function guardarDoctor(doctor, callback) {
  const query = 'INSERT INTO doctores (nombre, apellido, numeroced, especialidad, consultorio, correocont) VALUES (?, ?, ?, ?, ?, ?)';
  const values = [doctor.nombre, doctor.apellido, doctor.numeroced, doctor.especialidad, doctor.consultorio, doctor.correocont];

  connection.query(query, values, (err, result) => {
    if (err) {
      console.error('Error al guardar el doctor en la base de datos:', err);
      callback(err, null);
      return;
    }

    console.log('Doctor guardado en la base de datos');
    callback(null, result.insertId);
  });
}

module.exports = {
  guardarDoctor: guardarDoctor
};