# Formulario Persona

A Pen created on CodePen.io. Original URL: [https://codepen.io/NanaMFo/pen/qBQpjaa](https://codepen.io/NanaMFo/pen/qBQpjaa).

